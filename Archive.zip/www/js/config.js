var krms_config ={			
	'ApiUrl':"http://easy-eat.uk/mobileapp/api",		
	'DialogDefaultTitle’:"Easy Eat",	
	'pushNotificationSenderid':"60006061860",	
	'facebookAppId':"1669612006394979",
	'APIHasKey':"5d3b7e65271f83ffc8f82448d48d81cd"
};

